//
//  NSObject+ObjcOne.h
//  CoreOne
//
//  Created by Jeffrey Porter on 1/11/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ObjcOne : NSObject

- (NSString *)hello;

@end

NS_ASSUME_NONNULL_END
